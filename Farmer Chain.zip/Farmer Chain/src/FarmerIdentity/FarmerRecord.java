package FarmerIdentity;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

public class FarmerRecord extends FarmerRecordDetails {
    
    public String FarmerID;
    public String FarmerName;
    public String FarmerIncome;
    public String Gender;
    public String HealthCondition;
    public String OrganizationID;
    public String OrganizationName;
    
    public void addNew() { //inserting a new record in to the file
        //grasp all user data
        FarmerID = this.getFarmerID();
        FarmerName = this.getFarmerName();
        FarmerIncome = this.getFarmerIncome();
        Gender = this.getGender();
        HealthCondition = this.getHealthCondition();
        OrganizationID = this.getOrganizationID();
        OrganizationName = this.getOrganizationName();
        
        String line = ""; //this can all put in one line
        line += FarmerID + "|";
        line += FarmerName + "|";
        line += FarmerIncome + "|";
        line += Gender + "|";
        line += HealthCondition + "|";
        line += OrganizationID + "|";
        line += OrganizationName + "|";

        System.out.println("\n");

            try (PrintWriter writer = new PrintWriter(new FileOutputStream(f, true))) { //append into file
            //write to file
            writer.println(line);
            } catch (IOException e) {
            System.out.println(e.getMessage());
            }
        }
    
}

    
    
