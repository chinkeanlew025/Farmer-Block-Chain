package FarmerIdentity;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class TransactionPoolAdapter {
    
    public static void main(String[] args) {
        List<Transaction> trnsxLst = TransactionPoolAdapter.getTransaction();
        System.out.println( trnsxLst );
    }
    
    public static List<Transaction> getTransaction(){
        List<String> trnsxLst = Transaction.getAll();
        return trnsxLst.stream()
                .map( record -> record.split("\\|") )
                .filter( arr -> !arr[0].equals("DATANAME") )
                .map(arr -> new Transaction( arr[0], arr[1], arr[2], arr[3], arr[4], arr[5], arr[6]))
                .collect( Collectors.toList() );
    }
        
    public static List<List<String>>getTransactionHashes(){
        List<Transaction> TransactionPool = TransactionPoolAdapter.getTransaction();
        //generate hash value of each data in Transaction
            //collect using javatuple
        List<List<String>> hashLstAll = new ArrayList();
        for (Transaction trnsx : TransactionPool) {
            List<String> hashLst = new ArrayList();
            hashLst.add( HashingUtils.newhash(trnsx.getFarmerID(), "SHA-256") );
            hashLst.add( HashingUtils.newhash(trnsx.getFarmerName(), "SHA-256") );
            hashLst.add( HashingUtils.newhash(trnsx.getFarmerIncome(), "SHA-256") );
            hashLst.add( HashingUtils.newhash(trnsx.getGender(), "SHA-256") );
            hashLst.add( HashingUtils.newhash(trnsx.getHealthCondition(), "SHA-256") );
            hashLst.add( HashingUtils.newhash(trnsx.getOrganizationID(), "SHA-256") );
            hashLst.add( HashingUtils.newhash(trnsx.getOrganizationName(), "SHA-256") );
            hashLstAll.add(hashLst);
        }
        return hashLstAll;
    }
}


  
