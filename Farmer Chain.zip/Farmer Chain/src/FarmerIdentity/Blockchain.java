package FarmerIdentity;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Blockchain {
    
    private static final String CHAIN_OBJFILE = "master/chainobj.dat";

    public static void persist(LinkedList<Block> chain) {

        try (FileOutputStream fos = new FileOutputStream(CHAIN_OBJFILE);
                ObjectOutputStream out = new ObjectOutputStream(fos)) {
            out.writeObject(chain);
        } catch (Exception e) {
        }
    }

    public static LinkedList<Block> get() {

        try (FileInputStream fis = new FileInputStream(CHAIN_OBJFILE);
                ObjectInputStream in = new ObjectInputStream(fis)) {
            return (LinkedList<Block>) in.readObject();
        } catch (Exception e) {
            return null;
        }
    }

    public static void distribute( String temp, String publickeys, String privatekeys ){
        try {
            Files.write(Paths.get("Transaction.txt"), temp.getBytes(), StandardOpenOption.APPEND);
            Files.write(Paths.get("Transaction.txt"), publickeys.getBytes(), StandardOpenOption.APPEND);
            Files.write(Paths.get("Transaction.txt"), privatekeys.getBytes(), StandardOpenOption.APPEND);
        } catch (IOException ex) {
            
            Logger.getLogger(BlockchainIt.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
