package FarmerIdentity;

import java.io.IOException;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class Transaction {
    
    private static final String FILENAME = "TransactionPool.txt";
    
    private String FarmerID;
    private String FarmerName;
    private String FarmerIncome;
    private String Gender;
    private String HealthCondition;
    private String OrganizationID;
    private String OrganizationName;
    
    public Transaction (String FarmerID, String FarmerName, String FarmerIncome, String Gender, String HealthCondition, String OrganizationID, String OrganizationName) {
        
        this.FarmerID = FarmerID;
        this.FarmerName = FarmerName;
        this.FarmerIncome = FarmerIncome;
        this.Gender = Gender;
        this.HealthCondition = HealthCondition;
        this.OrganizationID = OrganizationID;
        this.OrganizationName = OrganizationName;
    }

    public String getFarmerID() {
        return FarmerID;
    }

    public void setFarmerID(String FarmerID) {
        this.FarmerID = FarmerID;
    }

    public String getFarmerName() {
        return FarmerName;
    }

    public void setFarmerName(String FarmerName) {
        this.FarmerName = FarmerName;
    }

    public String getFarmerIncome() {
        return FarmerIncome;
    }

    public void setFarmerIncome(String FarmerIncome) {
        this.FarmerIncome = FarmerIncome;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }

    public String getHealthCondition() {
        return HealthCondition;
    }

    public void setHealthCondition(String HealthCondition) {
        this.HealthCondition = HealthCondition;
    }

    public String getOrganizationID() {
        return OrganizationID;
    }

    public void setOrganizationID(String OrganizationID) {
        this.OrganizationID = OrganizationID;
    }

    public String getOrganizationName() {
        return OrganizationName;
    }

    public void setOrganizationName(String OrganizationName) {
        this.OrganizationName = OrganizationName;
    }
    
    public static List<String> getAll(){
        try {
            return Files.readAllLines(Paths.get(FILENAME)).stream().collect(Collectors.toList());
        } catch (IOException ex) {
            Logger.getLogger(FarmerRecordDetails.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public static void empty(){
        try {
            FileChannel.open(Paths.get(FILENAME), StandardOpenOption.WRITE).truncate(0).close();
        } catch (IOException ex) {
            Logger.getLogger(Transaction.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public String toString() {
        return "Data{" + "FarmerID=" + FarmerID + ", FarmerName=" + FarmerName + ", FarmerIncome=" + FarmerIncome + ", Gender=" + Gender + ", HealthCondition=" + HealthCondition + ", OrganizationID=" + OrganizationID + ", OrganizationName=" + OrganizationName + '}';
    }
}


