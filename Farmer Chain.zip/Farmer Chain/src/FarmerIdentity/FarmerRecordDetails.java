package FarmerIdentity;

import java.io.File;

public class FarmerRecordDetails {
    
    protected String FarmerID;
    protected String FarmerName;
    protected String FarmerIncome;
    protected String Gender;
    protected String HealthCondition;
    protected String OrganizationID;
    protected String OrganizationName;

    public String getFarmerID() {
        return FarmerID;
    }

    public void setFarmerID(String FarmerID) {
        this.FarmerID = FarmerID;
    }

    public String getFarmerName() {
        return FarmerName;
    }

    public void setFarmerName(String FarmerName) {
        this.FarmerName = FarmerName;
    }

    public String getFarmerIncome() {
        return FarmerIncome;
    }

    public void setFarmerIncome(String FarmerIncome) {
        this.FarmerIncome = FarmerIncome;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }

    public String getHealthCondition() {
        return HealthCondition;
    }

    public void setHealthCondition(String HealthCondition) {
        this.HealthCondition = HealthCondition;
    }

    public String getOrganizationID() {
        return OrganizationID;
    }

    public void setOrganizationID(String OrganizationID) {
        this.OrganizationID = OrganizationID;
    }

    public String getOrganizationName() {
        return OrganizationName;
    }

    public void setOrganizationName(String OrganizationName) {
        this.OrganizationName = OrganizationName;
    }
    
    File f = new File("Temp.txt");
}

    

