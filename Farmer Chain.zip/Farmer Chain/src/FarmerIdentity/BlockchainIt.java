package FarmerIdentity;

import com.google.gson.GsonBuilder;
import java.util.LinkedList;
import java.util.List;

public class BlockchainIt {
    
    //data structure implemented using linked list
    static LinkedList<Block> bchain = new LinkedList();
    
    public static void main(String[] args) {
    //firstBlock();
    nextBlock();

    }

    public static void firstBlock() {
       EncryptionDecryption ed = new EncryptionDecryption();
        System.out.println("--- Transaction objects ---");
        List<Transaction> TransactionPool = TransactionPoolAdapter.getTransaction();
       TransactionPool.stream().forEach( System.out::println );
        
        System.out.println("--- Transactions with hashes ---");
        List<List<String>> TransactionPool_hashes = TransactionPoolAdapter.getTransactionHashes();
        System.out.println( TransactionPool_hashes );

        Block b1 = new Block(TransactionPool_hashes, "0"); //genesis block
        bchain.add(b1);
        //clear the TransactionPool.txt
        Transaction.empty();
        Blockchain.persist(bchain); //store bchain object into chainobj.dat
        //distribute/display the linkedlist elements/blocks
        //Digital Signature
        byte[] encryptedText = ed.encryptText(bchain.getLast().getCurrentHash());
        String pubkey= "Public key: "+ EncryptionDecryption.keyToNumber(ed.getPublicKeyAsByteArray()).toString()+"\n";
        String privkey = "Private key: "+ EncryptionDecryption.keyToNumber(ed.getPrivateKeyAsByteArray()).toString()+"\n";
         out(bchain,pubkey,privkey);
         System.out.println(pubkey);
         System.out.println(privkey);
    }
  
    public static void nextBlock(){ 
         
        EncryptionDecryption ed = new EncryptionDecryption();
        List<List<String>> TransactionPool_hashes = TransactionPoolAdapter.getTransactionHashes();
        bchain = Blockchain.get();
        Block block = new Block(TransactionPool_hashes, bchain.getLast().getCurrentHash() );
        bchain.add(block);
        Transaction.empty();
        Blockchain.persist(bchain);
        //Digital Signature
        byte[] encryptedText = ed.encryptText(bchain.getLast().getCurrentHash());
        String pubkey= "Public key: "+ EncryptionDecryption.keyToNumber(ed.getPublicKeyAsByteArray()).toString()+"\n";
        String privkey = "Private key: "+EncryptionDecryption.keyToNumber(ed.getPrivateKeyAsByteArray()).toString()+"\n";
        out(bchain,pubkey,privkey);
        System.out.println(pubkey);
        System.out.println(privkey);
    }
    
    public static void out(LinkedList<Block> bchain, String pubkey, String privkey){
        String temp = new GsonBuilder().setPrettyPrinting().create().toJson(bchain);
        System.out.println( temp );
        Blockchain.distribute(temp,pubkey,privkey);
        
    }
    
}
