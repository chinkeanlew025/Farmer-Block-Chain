package medicalchain;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

public class MedicalRecord extends MedicalRecordDetails {
    
    public String PatientID;
    public String ClinicianID;
    public String HealthIssues;
    public String Medication;
    public String Payment;
    public String InsuranceCo;
    public String InsuranceNo;
    
    public void addNew() { //inserting a new record in to the file
        //grasp all user data
        PatientID = this.getPatientID();
        ClinicianID = this.getClinicianID();
        HealthIssues = this.getHealthIssues();
        Medication = this.getMedication();
        Payment = this.getPayment();
        InsuranceCo = this.getInsuranceCo();
        InsuranceNo = this.getInsuranceNo();
        
        String line = ""; //this can all put in one line
        line += PatientID + "|";
        line += ClinicianID + "|";
        line += HealthIssues + "|";
        line += Medication + "|";
        line += Payment + "|";
        line += InsuranceCo + "|";
        line += InsuranceNo + "|";

        System.out.println("\n");

            try (PrintWriter writer = new PrintWriter(new FileOutputStream(f, true))) { //append into file
            //write to file
            writer.println(line);
            } catch (IOException e) {
            System.out.println(e.getMessage());
            }
        }
    
}

    
    
