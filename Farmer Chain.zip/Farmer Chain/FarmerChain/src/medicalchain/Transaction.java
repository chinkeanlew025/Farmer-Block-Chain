package medicalchain;

import java.io.IOException;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class Transaction {
    
    private static final String FILENAME = "TransactionPool.txt";
    
    private String PatientID;
    private String ClinicianID;
    private String HealthIssues;
    private String Medication;
    private String Payment;
    private String InsuranceCo;
    private String InsuranceNo;
    
    public Transaction (String PatientID, String ClinicianID, String HealthIssues, String Medication, String Payment, String InsuranceCo, String InsuranceNo) {
        
        this.PatientID = PatientID;
        this.ClinicianID = ClinicianID;
        this.HealthIssues = HealthIssues;
        this.Medication = Medication;
        this.Payment = Payment;
        this.InsuranceCo = InsuranceCo;
        this.InsuranceNo = InsuranceNo;
    }

    public String getPatientID() {
        return PatientID;
    }

    public void setPatientID(String PatientID) {
        this.PatientID = PatientID;
    }

    public String getClinicianID() {
        return ClinicianID;
    }

    public void setClinicianID(String ClinicianID) {
        this.ClinicianID = ClinicianID;
    }

    public String getHealthIssues() {
        return HealthIssues;
    }

    public void setHealthIssues(String HealthIssues) {
        this.HealthIssues = HealthIssues;
    }

    public String getMedication() {
        return Medication;
    }

    public void setMedication(String Medication) {
        this.Medication = Medication;
    }

    public String getPayment() {
        return Payment;
    }

    public void setPaymentDate(String Payment) {
        this.Payment = Payment;
    }

    public String getInsuranceCo() {
        return InsuranceCo;
    }

    public void setInsuranceCo(String InsuranceCo) {
        this.InsuranceCo = InsuranceCo;
    }

    public String getInsuranceNo() {
        return InsuranceNo;
    }

    public void setInsuranceNo(String InsuranceNo) {
        this.InsuranceNo = InsuranceNo;
    }
    
    public static List<String> getAll(){
        try {
            return Files.readAllLines(Paths.get(FILENAME)).stream().collect(Collectors.toList());
        } catch (IOException ex) {
            Logger.getLogger(MedicalRecordDetails.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public static void empty(){
        try {
            FileChannel.open(Paths.get(FILENAME), StandardOpenOption.WRITE).truncate(0).close();
        } catch (IOException ex) {
            Logger.getLogger(Transaction.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public String toString() {
        return "Data{" + "PatientID=" + PatientID + ", ClinicianID=" + ClinicianID + ", HealthIssues=" + HealthIssues + ", Medication=" + Medication + ", Payment=" + Payment + ", InsuranceCo=" + InsuranceCo + ", InsuranceNo=" + InsuranceNo + '}';
    }
}


