package medicalchain;

import java.io.File;

public class MedicalRecordDetails {
    
    protected String PatientID;
    protected String ClinicianID;
    protected String HealthIssues;
    protected String Medication;
    protected String Payment;
    protected String InsuranceCo;
    protected String InsuranceNo;

    public String getPatientID() {
        return PatientID;
    }

    public void setPatientID(String PatientID) {
        this.PatientID = PatientID;
    }

    public String getClinicianID() {
        return ClinicianID;
    }

    public void setClinicianID(String ClinicianID) {
        this.ClinicianID = ClinicianID;
    }

    public String getHealthIssues() {
        return HealthIssues;
    }

    public void setHealthIssues(String HealthIssues) {
        this.HealthIssues = HealthIssues;
    }

    public String getMedication() {
        return Medication;
    }

    public void setMedication(String Medication) {
        this.Medication = Medication;
    }

    public String getPayment() {
        return Payment;
    }

    public void setPayment(String Payment) {
        this.Payment = Payment;
    }

    public String getInsuranceCo() {
        return InsuranceCo;
    }

    public void setInsuranceCo(String InsuranceCo) {
        this.InsuranceCo = InsuranceCo;
    }

    public String getInsuranceNo() {
        return InsuranceNo;
    }

    public void setInsuranceNo(String InsuranceNo) {
        this.InsuranceNo = InsuranceNo;
    }
    
    File f = new File("Temp.txt");
}

    

