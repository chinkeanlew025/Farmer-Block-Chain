package medicalchain;

public class Medicalchain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        BlockchainInterface bi = new BlockchainInterface();
        bi.setVisible(true);
    }
    
}
