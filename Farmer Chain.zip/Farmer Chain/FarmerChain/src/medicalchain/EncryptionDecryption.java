package medicalchain;

import java.math.BigInteger;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Base64;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public class EncryptionDecryption {
    
protected static String DEFAULT_ENCRYPTION_ALGORITHM = "RSA";
protected static int DEFAULT_ENCRYPTION_KEY_LENGTH = 1024;
protected static String DEFAULT_TRANSFORMATION = "RSA/ECB/PKCS1Padding";
protected String EncrypAlgorithm, Transaction;
protected int EncrypKeyLength;
protected PublicKey PublicKey;
protected PrivateKey PrivateKey;

    EncryptionDecryption()
    {
        EncrypAlgorithm = EncryptionDecryption.DEFAULT_ENCRYPTION_ALGORITHM;
        EncrypKeyLength = EncryptionDecryption.DEFAULT_ENCRYPTION_KEY_LENGTH;
        Transaction = EncryptionDecryption.DEFAULT_TRANSFORMATION;
        PublicKey = null;
        PrivateKey = null;
    }
    public static BigInteger keyToNumber(byte[] byteArray)
    {
        return new BigInteger(1, byteArray);
    }
    public String getEncrypAlgorithm()
    {
        return EncrypAlgorithm;
    }
    public int getEncrypKeyLength()
    {
        return EncrypKeyLength;
    }
    public String getTransaction()
    {
        return Transaction;
    }
    public PublicKey getPublicKey()
    {
        return PublicKey;
    }
    public byte[] getPublicKeyAsByteArray()
    {
        return PublicKey.getEncoded();
    }
    public String getEncodedPublicKey()
    {
        String encodedKey = Base64.getEncoder().encodeToString(PublicKey.getEncoded());
        return encodedKey;
    }
    public PrivateKey getPrivateKey()
    {
        return PrivateKey;
    }
    public byte[] getPrivateKeyAsByteArray()
    {
        return PrivateKey.getEncoded();
    }
    public String getEncodedPrivateKey()
    {
        String encodedKey = Base64.getEncoder().encodeToString(PrivateKey.getEncoded());
        return encodedKey;
    }
    public byte[] encryptText(String text)
    {
        byte[] encryptedText = null;
        try {
            KeyPairGenerator kpg = KeyPairGenerator.getInstance(EncrypAlgorithm);
            kpg.initialize(EncrypKeyLength);
            KeyPair kp = kpg.generateKeyPair();
            PublicKey = kp.getPublic();
            PrivateKey = kp.getPrivate();
            Cipher cipher = Cipher.getInstance(Transaction);
            cipher.init(Cipher.PUBLIC_KEY, PublicKey);
            encryptedText = cipher.doFinal(text.getBytes());
            } 
        catch (NoSuchAlgorithmException e)
        {e.printStackTrace();} 
        catch (NoSuchPaddingException e) 
        {e.printStackTrace();} 
        catch (InvalidKeyException e) 
        {e.printStackTrace();} 
        catch (IllegalBlockSizeException e) 
        {e.printStackTrace();} 
        catch (BadPaddingException e) 
        {e.printStackTrace();}
        
        return encryptedText;
    }

    public byte[] decryptText(byte[] encryptedText)
    {
        byte[] decryptedText = null;
            try {
                Cipher cipher = Cipher.getInstance(Transaction);
                cipher.init(Cipher.PRIVATE_KEY, PrivateKey);
                decryptedText = cipher.doFinal(encryptedText);
                } 
            catch (NoSuchAlgorithmException e)
            {e.printStackTrace();} 
            catch (NoSuchPaddingException e) 
            {e.printStackTrace();} 
            catch (InvalidKeyException e) 
            {e.printStackTrace();} 
            catch (IllegalBlockSizeException e) 
            {e.printStackTrace();} 
            catch (BadPaddingException e) 
            {e.printStackTrace();}
            
            return decryptedText;
    }
}
